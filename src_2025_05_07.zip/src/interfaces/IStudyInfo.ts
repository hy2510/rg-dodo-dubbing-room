interface IStudyInfo {
  studyId: string
  studentId: string
  studentHistoryId: string
}

export type { IStudyInfo }
